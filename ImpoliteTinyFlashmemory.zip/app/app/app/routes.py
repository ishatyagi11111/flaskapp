from flask import render_template, request, redirect, url_for, flash
from app import app
from deepface import DeepFace

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register_face():
    if request.method == 'POST':
        uploaded_file = request.files['file']
        if uploaded_file.filename != '':
            try:
                img_path = f'uploads/{uploaded_file.filename}'
                uploaded_file.save(img_path)

                # Register the face using DeepFace
                DeepFace.add(img_path)

                flash('Face registered successfully!', 'success')
            except Exception as e:
                flash(f'Error registering face: {str(e)}', 'danger')

    return render_template('register.html')

@app.route('/recognize', methods=['GET', 'POST'])
def recognize_face():
    if request.method == 'POST':
        uploaded_file = request.files['file']
        if uploaded_file.filename != '':
            try:
                img_path = f'uploads/{uploaded_file.filename}'
                uploaded_file.save(img_path)

                # Recognize the face using DeepFace
                result = DeepFace.verify("models", img_path, model_name="Facenet", distance_metric="euclidean_l2")

                if result["verified"]:
                    flash('Face recognized!', 'success')
                else:
                    flash('Face not recognized!', 'danger')
            except Exception as e:
                flash(f'Error recognizing face: {str(e)}', 'danger')

    return render_template('recognize.html')
